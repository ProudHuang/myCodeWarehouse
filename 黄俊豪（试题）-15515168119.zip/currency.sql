/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2018-07-20 00:21:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for currency
-- ----------------------------
DROP TABLE IF EXISTS `currency`;
CREATE TABLE `currency` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `fromcountry` varchar(255) DEFAULT NULL,
  `tocountry` varchar(255) DEFAULT NULL,
  `rate` double DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of currency
-- ----------------------------
INSERT INTO `currency` VALUES ('1', 'USD', 'CNY', '6.769');
INSERT INTO `currency` VALUES ('2', 'USD', 'JPY', '111.066');
INSERT INTO `currency` VALUES ('3', 'USD', 'GBP', '0.767');
INSERT INTO `currency` VALUES ('4', 'USD', 'EUR', '0.861');
INSERT INTO `currency` VALUES ('5', 'CNY', 'USD', '0.147');
INSERT INTO `currency` VALUES ('6', 'CNY', 'JPY', '16.712');
INSERT INTO `currency` VALUES ('7', 'CNY', 'EUR', '0.127');
INSERT INTO `currency` VALUES ('8', 'CNY', 'GBP', '0.113');
INSERT INTO `currency` VALUES ('9', 'JPY', 'USD', '0.008');
INSERT INTO `currency` VALUES ('10', 'JPY', 'CNY', '0.059');
INSERT INTO `currency` VALUES ('11', 'JPY', 'GBP', '0.006');
INSERT INTO `currency` VALUES ('12', 'JPY', 'EUR', '0.007');
INSERT INTO `currency` VALUES ('13', 'GBP', 'USD', '1.379');
INSERT INTO `currency` VALUES ('14', 'GBP', 'CNY', '8.805');
INSERT INTO `currency` VALUES ('15', 'GBP', 'JPY', '151.694');
INSERT INTO `currency` VALUES ('16', 'GBP', 'EUR', '1.143');
INSERT INTO `currency` VALUES ('17', 'EUR', 'USD', '1.163');
INSERT INTO `currency` VALUES ('18', 'EUR', 'CNY', '7.813');
INSERT INTO `currency` VALUES ('19', 'EUR', 'JPY', '128.872');
INSERT INTO `currency` VALUES ('20', 'EUR', 'GBP', '0.886');

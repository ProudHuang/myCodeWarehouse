package com.temple;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.temple.demo.ResultCurrency;
import com.temple.service.CurrencyService;

@RestController
public class CurrencyExchange {

	/**
	 * 请求
	 * http://127.0.0.1:8080/convert/{fromcountry}/{tocountry}
	 * 返回return
	 *  **/
	@Autowired
	private CurrencyService cuService;
	 
	 //提供了USD、CNY、JPY、GBP、EUR五类币种之间的汇率转换
	@RequestMapping("/convert/{fromcountry}/{tocountry}")
	@ResponseBody	
	public ResultCurrency Exchange(@PathVariable String fromcountry,@PathVariable String tocountry,double amount) {
		double rate=cuService.getRate(fromcountry, tocountry);
		double result=rate*amount;
		ResultCurrency rc=new ResultCurrency(result,rate,fromcountry, tocountry);
		return rc;
	}
	
	
}

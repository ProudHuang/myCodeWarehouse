package com.temple.mapper;



import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface CurrencyMapper {
	@Select("select rate from Currency where fromcountry=#{fromcountry} && tocountry=#{tocountry}")
	public double getRate(@Param("fromcountry")String fromcountry,@Param("tocountry")String tocountry);
}


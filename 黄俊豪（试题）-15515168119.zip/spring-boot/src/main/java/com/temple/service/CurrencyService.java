package com.temple.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.temple.mapper.CurrencyMapper;

@Service
public class CurrencyService {
     @Autowired
	 private CurrencyMapper cuMapper;
     
     
    public double getRate(String fromcountry,String tocountry){
		return cuMapper.getRate(fromcountry,tocountry);
    	
    }
}

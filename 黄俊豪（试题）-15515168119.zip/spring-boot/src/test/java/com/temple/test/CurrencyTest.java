package com.temple.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.temple.Application;
import com.temple.CurrencyExchange;
import com.temple.service.CurrencyService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class) // 指定spring-boot的启动类
public class CurrencyTest {

	@Autowired
	private CurrencyService cuService;
	 @Test
	public void currencyJunit() {
		 double rate=cuService.getRate("USD","CNY");
		 System.out.println(rate);
	}
}
